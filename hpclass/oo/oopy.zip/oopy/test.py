class account():

    def __init__(self):
        print "init has run"

    def credit(self):
        """ credit the account """

    def debit (self):
        """ debit the account"""

    


if __name__ == '__main__':

    
    myaccount = account()
